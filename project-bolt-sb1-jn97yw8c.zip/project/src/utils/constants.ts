export const education = [
  {
    degree: "Bachelor of Technology in Computer Science",
    institution: "Lovely Professional University",
    location: "Punjab",
    period: "2022 - 2026",
    status: "Current CGPA: 7.87"
  },
  {
    degree: "Higher Secondary Education",
    institution: "De Nobili School",
    location: "Mugma, Jharkhand",
    period: "2020 - 2022",
    status: "Grade : A"
  },
  {
    degree: "Secondary Education",
    institution: "De Nobili School",
    location: "Mugma, Jharkhand",
    period: "2020",
    status: "Grade : A"
  }
];