import React from 'react';
import { 
  Shield, 
  Code, 
  Network, 
  Lock, 
  Search, 
  AlertTriangle, 
  FileCode, 
  Database,
  Cloud,
  UserCheck,
  Terminal,
  FileDigit
} from 'lucide-react';

const Skills = ({ darkMode }: { darkMode: boolean }) => {
  return (
    <section 
      id="skills" 
      className={`py-20 ${
        darkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 font-mono ${
            darkMode ? 'text-cyan-400' : 'text-blue-600'
          }`}>
            <span className={darkMode ? 'text-white' : 'text-gray-800'}>Technical</span> Skills
          </h2>
          <div className={`h-1 w-20 mx-auto mb-6 ${
            darkMode ? 'bg-cyan-400' : 'bg-blue-600'
          }`}></div>
          <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Expertise in a wide range of cybersecurity domains, tools, and methodologies
          </p>
        </div>
        
        {/* Skill categories */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div 
              key={index} 
              className={`p-6 rounded-lg transition-all duration-300 ${
                darkMode 
                  ? 'bg-gray-900 hover:bg-gray-900/70 border border-gray-700' 
                  : 'bg-gray-50 hover:bg-gray-100 shadow-md'
              }`}
            >
              <div className="flex items-center mb-4">
                <div className={`p-3 rounded-md mr-3 ${
                  darkMode 
                    ? 'bg-gray-800 text-cyan-400' 
                    : 'bg-blue-100 text-blue-600'
                }`}>
                  {category.icon}
                </div>
                <h3 className="text-xl font-bold font-mono">{category.name}</h3>
              </div>
              
              <div className="space-y-3">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between mb-1">
                      <span className={`text-sm font-medium ${
                        darkMode ? 'text-gray-300' : 'text-gray-700'
                      }`}>
                        {skill.name}
                      </span>
                      <span className={`text-sm font-mono ${
                        darkMode ? 'text-cyan-400' : 'text-blue-600'
                      }`}>
                        {skill.level}%
                      </span>
                    </div>
                    <div className={`w-full h-2 rounded-full ${
                      darkMode ? 'bg-gray-700' : 'bg-gray-200'
                    }`}>
                      <div 
                        className={`h-2 rounded-full transition-all duration-1000 ${
                          darkMode ? 'bg-gradient-to-r from-blue-600 to-cyan-400' : 'bg-gradient-to-r from-blue-500 to-cyan-500'
                        }`} 
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        {/* Certifications & Tools */}
        <div className="mt-20 grid md:grid-cols-2 gap-12">
          {/* Certifications */}
          <div>
            <h3 className={`text-2xl font-bold mb-6 font-mono ${
              darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              <span className={darkMode ? 'text-cyan-400' : 'text-blue-600'}>Professional</span> Certifications
            </h3>
            <div className={`space-y-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {certifications.map((cert, index) => (
                <div 
                  key={index} 
                  className={`p-4 rounded-lg flex items-center ${
                    darkMode 
                      ? 'bg-gray-900 border border-gray-700' 
                      : 'bg-gray-50 shadow-sm'
                  }`}
                >
                  <div className={`p-2 rounded-md mr-4 ${
                    darkMode 
                      ? 'bg-gray-800 text-cyan-400' 
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    <FileDigit className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-medium">{cert.name}</h4>
                    <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{cert.issuer} • {cert.year}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Tools */}
          <div>
            <h3 className={`text-2xl font-bold mb-6 font-mono ${
              darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              <span className={darkMode ? 'text-cyan-400' : 'text-blue-600'}>Security</span> Tools
            </h3>
            <div className="flex flex-wrap gap-3">
              {tools.map((tool, index) => (
                <div 
                  key={index}
                  className={`px-4 py-3 rounded-lg text-sm flex items-center transition-all duration-300 ${
                    darkMode 
                      ? 'bg-gray-900 text-gray-300 border border-gray-700 hover:border-cyan-400/50' 
                      : 'bg-gray-50 text-gray-700 shadow-sm hover:shadow'
                  }`}
                >
                  <Terminal className="w-4 h-4 mr-2" />
                  {tool}
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Active learning */}
        <div className={`mt-16 p-6 rounded-lg ${
          darkMode 
            ? 'bg-gray-900/80 border border-gray-700' 
            : 'bg-blue-50 border border-blue-100'
        }`}>
          <div className="flex flex-col md:flex-row items-center">
            <div className={`p-4 rounded-full mb-4 md:mb-0 md:mr-6 ${
              darkMode 
                ? 'bg-gray-800 text-cyan-400' 
                : 'bg-blue-100 text-blue-600'
            }`}>
              <Search className="h-8 w-8" />
            </div>
            <div>
              <h3 className={`text-xl font-bold mb-2 ${
                darkMode ? 'text-white' : 'text-gray-800'
              }`}>
                Continuous Learning
              </h3>
              <p className={darkMode ? 'text-gray-300' : 'text-gray-600'}>
                The cybersecurity landscape evolves constantly. I stay current through ongoing education,
                research, and participation in security communities, ensuring my skills remain cutting-edge.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Skill categories with individual skills and proficiency levels
const skillCategories = [
  {
    name: "Penetration Testing",
    icon: <Shield className="h-6 w-6" />,
    skills: [
      { name: "Web Application Security", level: 95 },
      { name: "Network Security", level: 90 },
      { name: "Mobile Application Security", level: 65 },
      { name: "IoT Security", level: 80 }
    ]
  },
  {
    name: "Security Assessment",
    icon: <Search className="h-6 w-6" />,
    skills: [
      { name: "Vulnerability Assessment", level: 95 },
      { name: "Security Auditing", level: 90 },
      { name: "Threat Modeling", level: 85 },
      { name: "Risk Assessment", level: 90 }
    ]
  },
  {
    name: "Incident Response",
    icon: <AlertTriangle className="h-6 w-6" />,
    skills: [
      { name: "Digital Forensics", level: 85 },
      { name: "Malware Analysis", level: 80 },
      { name: "Threat Hunting", level: 90 },
      { name: "Incident Management", level: 95 }
    ]
  },
  {
    name: "Security Architecture",
    icon: <Lock className="h-6 w-6" />,
    skills: [
      { name: "Zero Trust Design", level: 90 },
      { name: "Cloud Security", level: 85 },
      { name: "DevSecOps", level: 60 },
      { name: "IAM Solutions", level: 95 }
    ]
  },
  {
    name: "Development",
    icon: <Code className="h-6 w-6" />,
    skills: [
      { name: "Secure Coding", level: 90 },
      { name: "Python", level: 95 },
      { name: "Bash/Shell Scripting", level: 90 },
      { name: "JavaScript/TypeScript", level: 55 }
    ]
  },
  {
    name: "Infrastructure",
    icon: <Database className="h-6 w-6" />,
    skills: [
      { name: "Linux Administration", level: 95 },
      { name: "Network Infrastructure", level: 70 },
      { name: "Containerization", level: 60 },
      { name: "Virtualization", level: 90 }
    ]
  }
];

// Professional certifications
const certifications = [
  { name: "Linux System Administration", issuer: "Lovely Professional University", year: "2024" },
  { name: "Linux+", issuer: "Cybrary", year: "2024" }
];

// Security tools
const tools = [
  "Metasploit", "Wireshark", "Nmap", 
  "Kali Linux", "Garuda", "VirtualBox",
  "Nessus", "Hashcat", "John the Ripper",
  "Git", "Airmon-ng", "wifite"
];

export default Skills;