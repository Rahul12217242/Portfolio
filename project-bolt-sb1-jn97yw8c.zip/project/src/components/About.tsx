import React from 'react';
import { Award, Briefcase, GraduationCap, UserCheck } from 'lucide-react';

const About = ({ darkMode }: { darkMode: boolean }) => {
  return (
    <section 
      id="about" 
      className={`py-20 ${
        darkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 font-mono ${
            darkMode ? 'text-cyan-400' : 'text-blue-600'
          }`}>
            <span className={darkMode ? 'text-white' : 'text-gray-800'}>About</span> Me
          </h2>
          <div className={`h-1 w-20 mx-auto mb-6 ${
            darkMode ? 'bg-cyan-400' : 'bg-blue-600'
          }`}></div>
          <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Dedicated cybersecurity professional with extensive experience in protecting organizations 
            from digital threats through strategic planning, penetration testing, and security architecture design.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className={`relative rounded-lg overflow-hidden ${darkMode ? 'border-2 border-cyan-400/20' : 'shadow-xl'}`}>
              <div className="aspect-w-4 aspect-h-5">
                <img 
                  src="https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Rahul Roy - Cybersecurity Expert" 
                  className="object-cover w-full h-full"
                />
              </div>
              
              {/* Overlay effect */}
              <div className={`absolute inset-0 bg-gradient-to-t ${
                darkMode 
                  ? 'from-black/80 via-black/20 to-transparent' 
                  : 'from-gray-900/70 via-gray-800/10 to-transparent'
              }`}></div>
              
              {/* Terminal-like decoration */}
              <div className="absolute top-4 left-4 right-4 h-8 bg-gray-900/80 backdrop-blur-sm rounded-t-md flex items-center px-4">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                <div className="text-xs text-gray-400 font-mono ml-2">~/rahul_roy/profile.sh</div>
              </div>
            </div>
          </div>

          <div>
            <h3 className={`text-2xl font-bold mb-6 font-mono ${
              darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              I'm a <span className={darkMode ? 'text-cyan-400' : 'text-blue-600'}>Cybersecurity Enthusiast</span> with a passion for digital protection
            </h3>
            
            <p className={`mb-6 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              I weave firewalls like poetry, shielding dreams in every connection.
From shadowy breaches to silent threats, I stand, unbroken.
Every encrypted whisper, every guarded gate, is a promise I've spoken.
In this ever-shifting cyberstorm, I'm the calm, the sword, the direction
            </p>
            
            <div className="grid grid-cols-2 gap-6 mb-8">
              {aboutItems.map((item, index) => (
                <div key={index} className="flex items-start">
                  <div className={`mr-3 mt-1 ${darkMode ? 'text-cyan-400' : 'text-blue-600'}`}>
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">{item.title}</h4>
                    <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex flex-wrap gap-4">
              {certifications.map((cert, index) => (
                <div 
                  key={index}
                  className={`px-4 py-2 rounded-full text-sm flex items-center ${
                    darkMode 
                      ? 'bg-gray-800 text-cyan-400 border border-cyan-400/30' 
                      : 'bg-blue-50 text-blue-700 border border-blue-200'
                  }`}
                >
                  <Award className="w-4 h-4 mr-2" />
                  {cert}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const aboutItems = [
  {
    title: "Penetration Testing",
    description: "Skilled in identifying vulnerabilities and security weaknesses",
    icon: <UserCheck className="w-5 h-5" />
  },
  {
    title: "Security Architecture",
    description: "Expert in designing robust security infrastructures",
    icon: <Briefcase className="w-5 h-5" />
  },
  {
    title: "Incident Response",
    description: "Experienced in handling security breaches effectively",
    icon: <GraduationCap className="w-5 h-5" />
  },
  {
    title: "Security Awareness",
    description: "Passionate about educating teams on security best practices",
    icon: <Award className="w-5 h-5" />
  }
];

const certifications = [
  "Linux System Adminstration",
  "Linux +"
  
];

export default About;