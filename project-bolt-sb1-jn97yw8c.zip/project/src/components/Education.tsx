import React from 'react';
import { GraduationCap, Calendar, MapPin } from 'lucide-react';
import { education } from '../utils/constants';

const Education = ({ darkMode }: { darkMode: boolean }) => {
  return (
    <section 
      id="education" 
      className={`py-20 ${
        darkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 font-mono ${
            darkMode ? 'text-cyan-400' : 'text-blue-600'
          }`}>
            <span className={darkMode ? 'text-white' : 'text-gray-800'}>Education</span> Journey
          </h2>
          <div className={`h-1 w-20 mx-auto mb-6 ${
            darkMode ? 'bg-cyan-400' : 'bg-blue-600'
          }`}></div>
          <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            My academic background and achievements
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Timeline line */}
          <div className={`absolute left-0 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-px ${
            darkMode ? 'bg-gray-700' : 'bg-gray-300'
          }`}></div>
          
          {/* Education items */}
          <div className="space-y-12">
            {education.map((item, index) => (
              <div 
                key={index} 
                className={`relative flex flex-col md:flex-row ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline dot */}
                <div className={`absolute left-0 md:left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full border-2 ${
                  darkMode 
                    ? 'border-cyan-400 bg-gray-900' 
                    : 'border-blue-500 bg-white'
                }`}></div>
                
                {/* Content */}
                <div className="ml-6 md:ml-0 md:w-1/2 md:px-8">
                  <div className={`p-6 rounded-xl shadow-xl transform transition-transform hover:scale-[1.02] ${
                    darkMode 
                      ? 'bg-gray-800 border border-gray-700' 
                      : 'bg-white border border-gray-200'
                  }`}>
                    <h3 className="text-xl font-bold mb-2">{item.degree}</h3>
                    <div className={`flex items-center gap-2 mb-1 ${
                      darkMode ? 'text-gray-400' : 'text-gray-600'
                    }`}>
                      <MapPin size={16} />
                      <div className="text-sm">{item.institution}, {item.location}</div>
                    </div>
                    <div className={`flex items-center gap-2 mb-4 ${
                      darkMode ? 'text-gray-400' : 'text-gray-600'
                    }`}>
                      <Calendar size={16} />
                      <div className="text-sm">{item.period}</div>
                    </div>
                    <div className={`inline-block px-3 py-1 rounded-full text-sm ${
                      darkMode 
                        ? 'bg-cyan-900/30 text-cyan-400' 
                        : 'bg-blue-100 text-blue-600'
                    }`}>
                      {item.status}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;