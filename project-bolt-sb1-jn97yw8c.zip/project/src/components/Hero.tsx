import React, { useState, useEffect } from 'react';
import { Shield, Lock, FileCode } from 'lucide-react';

const Hero = ({ darkMode }: { darkMode: boolean }) => {
  const [text, setText] = useState('');
  const [showCursor, setShowCursor] = useState(true);
  const [terminalLines, setTerminalLines] = useState<string[]>([]);
  const fullText = "Cybersecurity Nerd";
  const [currentIndex, setCurrentIndex] = useState(0);

  // Terminal animation
  useEffect(() => {
    const commands = [
      'nmap -sV -sC target.com',
      'sudo wireshark',
      'python3 exploit.py',
      'hashcat -m 0 hashes.txt wordlist.txt',
      'sqlmap -u "http://target.com" --dbs',
      'dirb http://target.com',
      'hydra -l admin -P wordlist.txt target.com ssh',
      'msfconsole',
      'john --wordlist=rockyou.txt hashes.txt',
      'aircrack-ng capture.cap',
    ];

    let currentLine = 0;
    const interval = setInterval(() => {
      if (currentLine < commands.length) {
        setTerminalLines(prev => [...prev, commands[currentLine]]);
        currentLine++;
      } else {
        setTerminalLines(commands);
        currentLine = 0;
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Typing effect
  useEffect(() => {
    if (currentIndex < fullText.length) {
      const timeout = setTimeout(() => {
        setText(prev => prev + fullText[currentIndex]);
        setCurrentIndex(currentIndex + 1);
      }, 100);
      return () => clearTimeout(timeout);
    }
  }, [currentIndex]);

  // Blinking cursor effect
  useEffect(() => {
    const interval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 500);
    return () => clearInterval(interval);
  }, []);

  return (
    <section 
      id="home"
      className="min-h-screen relative flex items-center justify-center overflow-hidden"
    >
      {/* Terminal Background */}
      <div className="terminal-background">
        <div className="terminal-content">
          {terminalLines.map((line, index) => (
            <div key={index} className="terminal-line">
              <span className="text-green-400">root@kali</span>
              <span className="text-blue-400">:~#</span> {line}
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          {/* Profile Image */}
          <div className="w-full md:w-1/2 flex justify-center md:justify-end">
            <div className="relative rounded-2xl overflow-hidden w-80 h-80 border-2 border-cyan-400/20">
              <img 
                src="https://raw.githubusercontent.com/Rahul12217242/Portfolio/main/unnamed.jpg" 
                alt="Rahul Roy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-transparent to-transparent"></div>
            </div>
          </div>

          {/* Text Content */}
          <div className="w-full md:w-1/2 text-center md:text-left md:pl-8">
            <h1 className="font-mono text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-white">
              <span className="block mb-4">Rahul Roy</span>
              <span className="flex items-center justify-center md:justify-start">
                <span className="text-cyan-400">{text}</span>
                <span className={`h-10 w-3 ml-1 ${showCursor ? 'bg-cyan-400' : 'bg-transparent'} transition-colors duration-100`}></span>
              </span>
            </h1>
            
            <p className="text-lg md:text-xl mb-8 text-gray-300">
              Protecting digital assets with advanced security solutions. 
              Specialized in penetration testing, vulnerability assessment, 
              and security architecture design.
            </p>

            <div className="flex flex-col sm:flex-row justify-center md:justify-start gap-4 mb-12">
              <button className="px-8 py-3 rounded-md bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-medium hover:shadow-lg hover:from-blue-700 hover:to-cyan-600 transition duration-300 flex items-center justify-center gap-2">
                <FileCode size={20} />
                View Projects
              </button>
              <button className="px-8 py-3 rounded-md font-medium transition duration-300 flex items-center justify-center gap-2 bg-gray-800 text-white hover:bg-gray-700">
                <Lock size={20} />
                Contact Me
              </button>
            </div>

            {/* Code Snippet */}
            <div className="max-w-2xl rounded-lg overflow-hidden bg-gray-800">
              <div className="flex items-center px-4 py-2 bg-gray-900">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <span className="ml-4 text-sm text-gray-400 font-mono">exploit.py</span>
              </div>
              <div className="p-4 font-mono text-sm">
                <pre className="text-left">
                  <code className="text-cyan-400">
{`#!/usr/bin/env python3

def scan_vulnerabilities(target):
    print(f"[*] Initiating security scan on {target}")
    vulnerabilities = []
    
    try:
        # Perform security checks
        check_open_ports(target)
        check_ssl_vulnerabilities(target)
        check_xss_vulnerabilities(target)
        check_sql_injection(target)
        
        return {
            'status': 'completed',
            'target': target,
            'findings': vulnerabilities
        }
    
    except Exception as e:
        return {
            'status': 'failed',
            'error': str(e)
        }

if __name__ == '__main__':
    target = "https://target.com"
    results = scan_vulnerabilities(target)
    print("[+] Scan completed successfully")`}
                  </code>
                </pre>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <a 
            href="#about" 
            className="animate-bounce flex items-center justify-center w-10 h-10 rounded-full bg-gray-800 text-cyan-400"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;