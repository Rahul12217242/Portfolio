import React, { useState } from 'react';
import { Send, Mail, Phone, MapPin, Shield, AlertTriangle } from 'lucide-react';

const Contact = ({ darkMode }: { darkMode: boolean }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    
    if (!formData.subject.trim()) newErrors.subject = 'Subject is required';
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const formErrors = validateForm();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitStatus({
        success: true,
        message: 'Your message has been sent! I will get back to you shortly.'
      });
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
      
      // Clear success message after 5 seconds
      setTimeout(() => {
        setSubmitStatus(null);
      }, 5000);
    }, 1500);
  };

  return (
    <section 
      id="contact" 
      className={`py-20 ${
        darkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 font-mono ${
            darkMode ? 'text-cyan-400' : 'text-blue-600'
          }`}>
            <span className={darkMode ? 'text-white' : 'text-gray-800'}>Contact</span> Me
          </h2>
          <div className={`h-1 w-20 mx-auto mb-6 ${
            darkMode ? 'bg-cyan-400' : 'bg-blue-600'
          }`}></div>
          <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Let's discuss how I can help secure your digital assets and strengthen your security posture
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-10">
          {/* Contact information */}
          <div className="md:col-span-1">
            <div className={`p-6 rounded-lg mb-6 ${
              darkMode 
                ? 'bg-gray-900 border border-gray-700' 
                : 'bg-gray-50 shadow-md'
            }`}>
              <h3 className={`text-xl font-bold mb-6 font-mono ${
                darkMode ? 'text-white' : 'text-gray-800'
              }`}>
                Contact Information
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className={`p-3 rounded-md mr-4 ${
                    darkMode 
                      ? 'bg-gray-800 text-cyan-400' 
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className={`font-medium mb-1 ${
                      darkMode ? 'text-gray-200' : 'text-gray-700'
                    }`}>
                      Email
                    </h4>
                    <a 
                      href="mailto:john.doe@secureportfolio.com"
                      className={`text-sm ${
                        darkMode ? 'text-cyan-400 hover:text-cyan-300' : 'text-blue-600 hover:text-blue-700'
                      }`}
                    >
                      aliferousrahul@gmail.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className={`p-3 rounded-md mr-4 ${
                    darkMode 
                      ? 'bg-gray-800 text-cyan-400' 
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className={`font-medium mb-1 ${
                      darkMode ? 'text-gray-200' : 'text-gray-700'
                    }`}>
                      Phone
                    </h4>
                    <a 
                      href="tel:+11234567890"
                      className={`text-sm ${
                        darkMode ? 'text-cyan-400 hover:text-cyan-300' : 'text-blue-600 hover:text-blue-700'
                      }`}
                    >
                      +91 9142770584
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className={`p-3 rounded-md mr-4 ${
                    darkMode 
                      ? 'bg-gray-800 text-cyan-400' 
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className={`font-medium mb-1 ${
                      darkMode ? 'text-gray-200' : 'text-gray-700'
                    }`}>
                      Location
                    </h4>
                    <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                      AGI Sky Garden, Jalandhar<br />
                      India
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Security note */}
            <div className={`p-6 rounded-lg ${
              darkMode 
                ? 'bg-gray-900 border border-gray-700' 
                : 'bg-blue-50 border border-blue-100'
            }`}>
              <div className="flex items-start">
                <div className={`p-3 rounded-md mr-4 ${
                  darkMode 
                    ? 'bg-gray-800 text-cyan-400' 
                    : 'bg-blue-100 text-blue-600'
                }`}>
                  <Shield className="h-5 w-5" />
                </div>
                <div>
                  <h4 className={`font-medium mb-1 ${
                    darkMode ? 'text-white' : 'text-gray-800'
                  }`}>
                    Secure Communication
                  </h4>
                  <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    For sensitive inquiries, please use the PGP key available on my GitHub profile for encrypted communication.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact form */}
          <div className="md:col-span-2">
            <div className={`p-8 rounded-lg ${
              darkMode 
                ? 'bg-gray-900 border border-gray-700' 
                : 'bg-white shadow-lg'
            }`}>
              <h3 className={`text-xl font-bold mb-6 font-mono ${
                darkMode ? 'text-white' : 'text-gray-800'
              }`}>
                Send Me a Message
              </h3>
              
              {submitStatus && (
                <div className={`p-4 mb-6 rounded-md ${
                  submitStatus.success 
                    ? darkMode ? 'bg-green-900/30 text-green-400 border border-green-800' : 'bg-green-100 text-green-800 border border-green-200'
                    : darkMode ? 'bg-red-900/30 text-red-400 border border-red-800' : 'bg-red-100 text-red-800 border border-red-200'
                }`}>
                  <div className="flex items-center">
                    {submitStatus.success ? (
                      <Shield className="h-5 w-5 mr-2" />
                    ) : (
                      <AlertTriangle className="h-5 w-5 mr-2" />
                    )}
                    {submitStatus.message}
                  </div>
                </div>
              )}
              
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label 
                      htmlFor="name" 
                      className={`block text-sm font-medium mb-2 ${
                        darkMode ? 'text-gray-300' : 'text-gray-700'
                      }`}
                    >
                      Name
                    </label>
                    <input 
                      type="text" 
                      id="name" 
                      name="name" 
                      value={formData.name}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 rounded-md ${
                        darkMode 
                          ? 'bg-gray-800 border border-gray-700 text-white focus:border-cyan-400' 
                          : 'bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500'
                      } focus:outline-none focus:ring-2 ${
                        darkMode ? 'focus:ring-cyan-400/20' : 'focus:ring-blue-500/20'
                      }`}
                      placeholder="Your name"
                    />
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-500">{errors.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label 
                      htmlFor="email" 
                      className={`block text-sm font-medium mb-2 ${
                        darkMode ? 'text-gray-300' : 'text-gray-700'
                      }`}
                    >
                      Email
                    </label>
                    <input 
                      type="email" 
                      id="email" 
                      name="email" 
                      value={formData.email}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 rounded-md ${
                        darkMode 
                          ? 'bg-gray-800 border border-gray-700 text-white focus:border-cyan-400' 
                          : 'bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500'
                      } focus:outline-none focus:ring-2 ${
                        darkMode ? 'focus:ring-cyan-400/20' : 'focus:ring-blue-500/20'
                      }`}
                      placeholder="your.email@example.com"
                    />
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                    )}
                  </div>
                </div>
                
                <div className="mb-6">
                  <label 
                    htmlFor="subject" 
                    className={`block text-sm font-medium mb-2 ${
                      darkMode ? 'text-gray-300' : 'text-gray-700'
                    }`}
                  >
                    Subject
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className={`w-full px-4 py-3 rounded-md ${
                      darkMode 
                        ? 'bg-gray-800 border border-gray-700 text-white focus:border-cyan-400' 
                        : 'bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500'
                    } focus:outline-none focus:ring-2 ${
                      darkMode ? 'focus:ring-cyan-400/20' : 'focus:ring-blue-500/20'
                    }`}
                  >
                    <option value="" disabled>Select a subject</option>
                    <option value="Consultation Request">Consultation Request</option>
                    <option value="Security Assessment">Security Assessment</option>
                    <option value="Training Inquiry">Training Inquiry</option>
                    <option value="Project Collaboration">Project Collaboration</option>
                    <option value="Other">Other</option>
                  </select>
                  {errors.subject && (
                    <p className="mt-1 text-sm text-red-500">{errors.subject}</p>
                  )}
                </div>
                
                <div className="mb-6">
                  <label 
                    htmlFor="message" 
                    className={`block text-sm font-medium mb-2 ${
                      darkMode ? 'text-gray-300' : 'text-gray-700'
                    }`}
                  >
                    Message
                  </label>
                  <textarea 
                    id="message" 
                    name="message" 
                    rows={5} 
                    value={formData.message}
                    onChange={handleChange}
                    className={`w-full px-4 py-3 rounded-md ${
                      darkMode 
                        ? 'bg-gray-800 border border-gray-700 text-white focus:border-cyan-400' 
                        : 'bg-gray-50 border border-gray-200 text-gray-900 focus:border-blue-500'
                    } focus:outline-none focus:ring-2 ${
                      darkMode ? 'focus:ring-cyan-400/20' : 'focus:ring-blue-500/20'
                    }`}
                    placeholder="Your message"
                  ></textarea>
                  {errors.message && (
                    <p className="mt-1 text-sm text-red-500">{errors.message}</p>
                  )}
                </div>
                
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className={`px-6 py-3 rounded-md font-medium flex items-center justify-center ${
                    isSubmitting 
                      ? darkMode ? 'bg-gray-700 text-gray-400' : 'bg-gray-300 text-gray-600'
                      : 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white hover:from-blue-700 hover:to-cyan-600'
                  } transition duration-300 w-full sm:w-auto`}
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5 mr-2" />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;