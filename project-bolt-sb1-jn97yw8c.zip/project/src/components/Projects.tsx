import React, { useState } from 'react';
import { 
  Shield, 
  ExternalLink, 
  GitBranch, 
  Lock, 
  AlertTriangle, 
  Eye, 
  Tag 
} from 'lucide-react';

const Projects = ({ darkMode }: { darkMode: boolean }) => {
  const [filter, setFilter] = useState('all');
  
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);

  return (
    <section 
      id="projects" 
      className={`py-20 ${
        darkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-800'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 font-mono ${
            darkMode ? 'text-cyan-400' : 'text-blue-600'
          }`}>
            <span className={darkMode ? 'text-white' : 'text-gray-800'}>Security</span> Projects
          </h2>
          <div className={`h-1 w-20 mx-auto mb-6 ${
            darkMode ? 'bg-cyan-400' : 'bg-blue-600'
          }`}></div>
          <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            A showcase of my recent cybersecurity projects, tools, and research
          </p>
        </div>
        
        {/* Filter options */}
        <div className="flex flex-wrap justify-center gap-3 mb-10">
          {filters.map(filterOption => (
            <button
              key={filterOption.value}
              onClick={() => setFilter(filterOption.value)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-300 ${
                filter === filterOption.value
                  ? darkMode 
                    ? 'bg-cyan-500 text-white' 
                    : 'bg-blue-600 text-white'
                  : darkMode 
                    ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {filterOption.label}
            </button>
          ))}
        </div>
        
        {/* Projects grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div 
              key={index}
              className={`rounded-lg overflow-hidden transition-all duration-300 transform hover:-translate-y-1 ${
                darkMode 
                  ? 'bg-gray-800 border border-gray-700' 
                  : 'bg-white shadow-lg'
              }`}
            >
              {/* Project image with overlay */}
              <div className="relative overflow-hidden h-56">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="object-cover w-full h-full transition-transform duration-500 hover:scale-110"
                />
                <div className={`absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300 ${
                  darkMode 
                    ? 'bg-gray-900/80 backdrop-blur-sm' 
                    : 'bg-blue-600/60 backdrop-blur-sm'
                }`}>
                  <div className="flex gap-4">
                    <a 
                      href={project.demoLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className={`p-3 rounded-full ${
                        darkMode 
                          ? 'bg-gray-800 text-cyan-400 hover:bg-gray-700' 
                          : 'bg-white/20 text-white hover:bg-white/30'
                      }`}
                    >
                      <Eye className="h-5 w-5" />
                    </a>
                    <a 
                      href={project.githubLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className={`p-3 rounded-full ${
                        darkMode 
                          ? 'bg-gray-800 text-cyan-400 hover:bg-gray-700' 
                          : 'bg-white/20 text-white hover:bg-white/30'
                      }`}
                    >
                      <GitBranch className="h-5 w-5" />
                    </a>
                  </div>
                </div>
                
                {/* Security classification tag */}
                <div className={`absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold font-mono flex items-center ${
                  project.securityLevel === 'High' 
                    ? 'bg-red-500/90 text-white' 
                    : project.securityLevel === 'Medium'
                      ? 'bg-yellow-500/90 text-gray-900'
                      : 'bg-green-500/90 text-white'
                }`}>
                  <Lock className="h-3 w-3 mr-1" />
                  {project.securityLevel} Risk
                </div>
              </div>
              
              {/* Project details */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-bold">{project.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded-md ${
                    darkMode 
                      ? 'bg-gray-700 text-gray-300' 
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {project.category}
                  </span>
                </div>
                <p className={`text-sm mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  {project.description}
                </p>
                
                {/* Technologies used */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className={`text-xs px-2 py-1 rounded ${
                        darkMode 
                          ? 'bg-gray-700 text-cyan-400' 
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                {/* Link to full project */}
                <a 
                  href={project.demoLink} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`inline-flex items-center text-sm font-medium ${
                    darkMode 
                      ? 'text-cyan-400 hover:text-cyan-300' 
                      : 'text-blue-600 hover:text-blue-700'
                  }`}
                >
                  View Project Details
                  <ExternalLink className="h-4 w-4 ml-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
        
        {/* Call to action */}
        <div className={`mt-16 p-8 rounded-lg text-center ${
          darkMode 
            ? 'bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-700' 
            : 'bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-100'
        }`}>
          <h3 className={`text-2xl font-bold mb-4 ${
            darkMode ? 'text-white' : 'text-gray-800'
          }`}>
            Interested in Collaboration?
          </h3>
          <p className={`max-w-2xl mx-auto mb-6 ${
            darkMode ? 'text-gray-300' : 'text-gray-600'
          }`}>
            I'm always open to discussing new security projects, challenges, and opportunities.
          </p>
          <a 
            href="#contact" 
            className="px-8 py-3 rounded-md bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-medium hover:shadow-lg hover:from-blue-700 hover:to-cyan-600 transition duration-300 inline-flex items-center"
          >
            <Shield className="h-5 w-5 mr-2" />
            Get in Touch
          </a>
        </div>
      </div>
    </section>
  );
};

// Filter options
const filters = [
  { label: 'All Projects', value: 'all' },
  { label: 'Penetration Testing', value: 'pentest' },
  { label: 'Security Tools', value: 'tools' },
  { label: 'Research', value: 'research' },
  { label: 'Security Architecture', value: 'architecture' }
];

// Project data
const projects = [
  {
    title: 'Network Scanner: Cybersecurity Project',
    description: 'Implemented a Python-based network scanner to perform reconnaissance of local networks. Leveraged the socket and ipaddress libraries to identify active hosts within a specified subnet. Incorporated threading to accelerate scanning processes and enhance performance. Assisted in identifying potential targets and open services during the information gathering phase of penetration testing.',
    image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'tools',
    technologies: ['Python'],
    demoLink: '#',
    githubLink: '#',
    securityLevel: 'High'
  },
  {
    title: 'PDF password cracker: Cybersecurity Project',
    description: 'Designed a PDF password cracker to recover access to locked documents using brute-force techniques. Utilized Python with PyPDF2 and pikepdf libraries to implement a dictionary-based attack. Employed a wordlist-based approach, iterating through potential passwords to attempt decryption. Demonstrated high effectiveness for weak passwords, with performance dependent on password complexity and dictionary strength. Executed sequential decryption attempts until a valid password was identified.',
    image: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'architecture',
    technologies: ['Python', 'PyPDF2', 'pikepdf'],
    demoLink: '#',
    githubLink: '#',
    securityLevel: 'Medium'
  },
  {
    title: 'Keylogger for security auditing: Cybersecurity Project',
    description: 'Developed a keylogger to capture and log user keystrokes for security auditing and ethical hacking demonstrations. Recorded keystroke data using the Pynput library for post-event analysis. Designed the application to operate discreetly in the background without disrupting system performance. Built the project to emphasize responsible usage in cybersecurity training labs and penetration testing scenarios. Logged captured inputs systematically in a local file for detailed behavioral study.',
    image: 'https://images.pexels.com/photos/8847044/pexels-photo-8847044.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'pentest',
    technologies: ['Python', 'Pyinput Library'],
    demoLink: '#',
    githubLink: '#',
    securityLevel: 'High'
  }
];

export default Projects;