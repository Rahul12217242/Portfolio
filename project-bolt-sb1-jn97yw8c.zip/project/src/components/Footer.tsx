import React from 'react';
import { Shield, Github, Linkedin, Twitter, Rss, ArrowUp } from 'lucide-react';

const Footer = ({ darkMode }: { darkMode: boolean }) => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className={`py-12 ${
      darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-800'
    }`}>
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Logo & description */}
          <div className="md:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-4">
              <Shield className={`h-8 w-8 ${darkMode ? 'text-cyan-400' : 'text-blue-600'}`} />
              <span className="font-mono text-xl font-bold tracking-tight">
                <span className={darkMode ? 'text-cyan-400' : 'text-blue-600'}>Bruteforcing</span> into Reality
              </span>
            </a>
            <p className={`text-sm mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Dedicated to advancing cybersecurity through expertise, innovation, and collaboration.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a 
                  key={index}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`p-2 rounded-full transition-colors duration-300 ${
                    darkMode 
                      ? 'text-gray-400 hover:text-cyan-400 hover:bg-gray-800' 
                      : 'text-gray-600 hover:text-blue-600 hover:bg-gray-200'
                  }`}
                  aria-label={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
          
          {/* Quick links */}
          <div>
            <h3 className={`text-lg font-bold mb-4 ${
              darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              Quick Links
            </h3>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.url}
                    className={`text-sm hover:underline ${
                      darkMode ? 'text-gray-400 hover:text-cyan-400' : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h3 className={`text-lg font-bold mb-4 ${
              darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              Services
            </h3>
            <ul className="space-y-2">
              {services.map((service, index) => (
                <li key={index}>
                  <a 
                    href="#"
                    className={`text-sm hover:underline ${
                      darkMode ? 'text-gray-400 hover:text-cyan-400' : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h3 className={`text-lg font-bold mb-4 ${
              darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              Legal
            </h3>
            <ul className="space-y-2">
              {legalLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href="#"
                    className={`text-sm hover:underline ${
                      darkMode ? 'text-gray-400 hover:text-cyan-400' : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className={`h-px w-full my-8 ${darkMode ? 'bg-gray-800' : 'bg-gray-200'}`}></div>
        
        {/* Bottom section */}
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            © {new Date().getFullYear()} Bruteforcing into Reality. All rights reserved.
          </p>
          
          <button 
            onClick={scrollToTop}
            className={`mt-4 md:mt-0 p-3 rounded-full transition-colors duration-300 ${
              darkMode 
                ? 'bg-gray-800 text-gray-400 hover:text-cyan-400' 
                : 'bg-gray-200 text-gray-600 hover:text-blue-600'
            }`}
            aria-label="Scroll to top"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </div>
      </div>
    </footer>
  );
};

// Social media links
const socialLinks = [
  { name: 'GitHub', url: '#', icon: <Github className="h-5 w-5" /> },
  { name: 'LinkedIn', url: '#', icon: <Linkedin className="h-5 w-5" /> },
  { name: 'Twitter', url: '#', icon: <Twitter className="h-5 w-5" /> },
  { name: 'Blog', url: '#', icon: <Rss className="h-5 w-5" /> }
];

// Quick navigation links
const quickLinks = [
  { name: 'Home', url: '#home' },
  { name: 'About', url: '#about' },
  { name: 'Skills', url: '#skills' },
  { name: 'Projects', url: '#projects' },
  { name: 'Contact', url: '#contact' }
];

// Services
const services = [
  'Security Assessments',
  'Penetration Testing',
  'Security Architecture',
  'Incident Response',
  'Security Training'
];

// Legal links
const legalLinks = [
  'Terms of Service',
  'Privacy Policy',
  'Cookie Policy',
  'Disclaimer'
];

export default Footer;