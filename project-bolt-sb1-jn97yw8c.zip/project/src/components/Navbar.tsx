import React, { useState, useEffect } from 'react';
import { Shield, Menu, X, Sun, Moon } from 'lucide-react';

const Navbar = ({ darkMode, toggleDarkMode }: { darkMode: boolean, toggleDarkMode: () => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-black/80 backdrop-blur-md shadow-lg' : 'bg-transparent'
      } ${darkMode ? 'text-gray-100' : 'text-gray-800'}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <a href="#" className="flex items-center gap-2">
                <Shield className={`h-8 w-8 ${darkMode ? 'text-cyan-400' : 'text-blue-600'}`} />
                <span className="font-mono text-xl font-bold tracking-tight">
                  Bruteforcing into Reality
                </span>
              </a>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              <NavLinks darkMode={darkMode} />
              <button 
                onClick={toggleDarkMode}
                className={`p-2 rounded-full ${darkMode ? 'bg-gray-800 text-yellow-300 hover:bg-gray-700' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
                aria-label="Toggle dark mode"
              >
                {darkMode ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            </div>
          </div>
          
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleDarkMode}
              className={`p-2 mr-2 rounded-full ${darkMode ? 'bg-gray-800 text-yellow-300' : 'bg-gray-200 text-gray-700'}`}
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`inline-flex items-center justify-center p-2 rounded-md ${
                darkMode 
                  ? 'text-gray-200 hover:bg-gray-800' 
                  : 'text-gray-700 hover:bg-gray-200'
              }`}
              aria-label="Open main menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className={`md:hidden ${darkMode ? 'bg-black/95' : 'bg-white/95'} backdrop-blur-lg`}>
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <NavLinks darkMode={darkMode} mobile setMobileMenuOpen={setMobileMenuOpen} />
          </div>
        </div>
      )}
    </nav>
  );
};

const NavLinks = ({ 
  darkMode, 
  mobile = false,
  setMobileMenuOpen = () => {}
}: { 
  darkMode: boolean, 
  mobile?: boolean,
  setMobileMenuOpen?: (open: boolean) => void 
}) => {
  const links = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Projects', href: '#projects' },
    { name: 'Contact', href: '#contact' },
  ];

  const baseClasses = darkMode 
    ? 'transition-colors duration-200 hover:text-cyan-400' 
    : 'transition-colors duration-200 hover:text-blue-600';
  
  const mobileClasses = mobile
    ? `block px-3 py-2 rounded-md text-base font-medium ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-200'}`
    : 'px-3 py-2 rounded-md text-sm font-medium';

  const combinedClasses = `${baseClasses} ${mobileClasses}`;

  const handleClick = () => {
    if (mobile) {
      setMobileMenuOpen(false);
    }
  };

  return (
    <>
      {links.map((link) => (
        <a
          key={link.name}
          href={link.href}
          onClick={handleClick}
          className={combinedClasses}
        >
          {link.name}
        </a>
      ))}
    </>
  );
};

export default Navbar;