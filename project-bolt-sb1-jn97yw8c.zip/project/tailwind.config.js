/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['Fira Code', 'JetBrains Mono', 'monospace']
      },
      colors: {
        // Custom colors for cybersecurity theme
        'cyber-blue': {
          50: '#EBF8FF',
          100: '#D1EEFC',
          200: '#A7D8F0',
          300: '#7CC1E4',
          400: '#55A5D9',
          500: '#3B82F6', // Primary
          600: '#2451B7',
          700: '#1D3D91',
          800: '#112269',
          900: '#0A1333',
        },
        'cyber-cyan': {
          400: '#22D3EE',
          500: '#06B6D4',
        },
      },
      animation: {
        'terminal-cursor': 'blink 1s step-start infinite',
      },
      keyframes: {
        blink: {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0 },
        },
      },
      boxShadow: {
        'terminal': '0 0 15px rgba(34, 211, 238, 0.5)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'cyber-grid': "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M54.627 0l.83.828-1.415 1.415L51.8 0h2.827zM5.373 0l-.83.828L5.96 2.243 8.2 0H5.374zM48.97 0l3.657 3.657-1.414 1.414L46.143 0h2.828zM11.03 0L7.372 3.657l1.415 1.414L13.858 0H11.03zm32.284 0L39.9 3.414 42.28 0h1.032zm-9.9 0L29 3.414 26.62 0h5.8zM16.686 0L10.9 5.786 14.314 0h2.372zm24.628 0l5.786 5.786L43.314 0h-2z' fill='%230099cc' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E\")",
      },
    },
  },
  plugins: [],
};